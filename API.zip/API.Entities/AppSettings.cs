namespace API.Entities
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}